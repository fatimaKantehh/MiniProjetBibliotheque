// Roman.java
public class Roman extends Livre {
    private String genre;
    private boolean estUneSerie;
    private int numeroDansLaSerie;

    public Roman(String titre, String auteur, int anneePublication, String ISBN, String genre, boolean estUneSerie,
            int numeroDansLaSerie) {
        super(titre, auteur, anneePublication, ISBN);
        this.genre = genre;
        this.estUneSerie = estUneSerie;
        this.numeroDansLaSerie = numeroDansLaSerie;
    }

    // Getters et Setters pour les attributs spécifiques de Roman
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public boolean EstUneSerie() {
        return estUneSerie;
    }

    public void setEstUneSerie(boolean estUneSerie) {
        this.estUneSerie = estUneSerie;
    }

    public int getNumeroDansLaSerie() {
        return numeroDansLaSerie;
    }

    public void setNumeroDansLaSerie(int numeroDansLaSerie) {
        this.numeroDansLaSerie = numeroDansLaSerie;
    }

    @Override
    public String toString() {
        return "Roman{" +
                "titre='" + getTitre() + '\'' +
                ", auteur='" + getAuteur() + '\'' +
                ", anneePublication=" + getAnneePublication() +
                ", ISBN='" + getISBN() + '\'' +
                ", genre='" + genre + '\'' +
                ", estUneSerie=" + estUneSerie +
                ", numeroDansLaSerie=" + numeroDansLaSerie +
                '}';
    }
}
