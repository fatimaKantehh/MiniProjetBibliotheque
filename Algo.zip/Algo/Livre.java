public class Livre {
    // Attributs de la classe Livre
    private String titre;
    private String auteur;
    private int anneePublication;
    private String ISBN;

    // Constructeur de la classe Livre
    public Livre(String titre, String auteur, int anneePublication, String ISBN) {
        this.titre = titre;
        this.auteur = auteur;
        this.anneePublication = anneePublication;
        this.ISBN = ISBN;
    }

    // Getters et setters pour chaque attribut
    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getAuteur() {
        return auteur;
    }

    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }

    public int getAnneePublication() {
        return anneePublication;
    }

    public void setAnneePublication(int anneePublication) {
        this.anneePublication = anneePublication;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    private boolean estEmprunte;

    public Livre() {
        // initialisation des attributs
        this.estEmprunte = false;
    }

    // ... autres méthodes ...

    // Méthode pour vérifier si le livre est emprunté
    public boolean estEmprunte() {
        return estEmprunte;
    }

    // Méthode pour marquer un livre comme emprunté
    public void emprunter() {
        this.estEmprunte = true;
    }

    // Méthode pour marquer un livre comme non emprunté
    public void retourner() {
        this.estEmprunte = false;
    }

    // Méthode toString() pour afficher les informations du livre
    @Override
    public String toString() {
        return "Titre: " + titre + "\n" +
                "Auteur: " + auteur + "\n" +
                "ISBN: " + ISBN;
    }
}
