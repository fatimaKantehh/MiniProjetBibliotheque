// LivreAudio.java
public class LivreAudio extends Livre {
    private int dureeEnMinutes;
    private String narrateur;

    public LivreAudio(String titre, String auteur, int anneePublication, String ISBN, int dureeEnMinutes,
            String narrateur) {
        super(titre, auteur, anneePublication, ISBN);
        this.dureeEnMinutes = dureeEnMinutes;
        this.narrateur = narrateur;
    }

    // Getters et setters pour 'dureeEnMinutes'
    public int getDureeEnMinutes() {
        return dureeEnMinutes;
    }

    public void setDureeEnMinutes(int dureeEnMinutes) {
        this.dureeEnMinutes = dureeEnMinutes;
    }

    // Getters et setters pour 'narrateur'
    public String getNarrateur() {
        return narrateur;
    }

    public void setNarrateur(String narrateur) {
        this.narrateur = narrateur;
    }

    @Override
    public String toString() {
        return "LivreAudio{" +
                "titre='" + getTitre() + '\'' +
                ", auteur='" + getAuteur() + '\'' +
                ", anneePublication=" + getAnneePublication() +
                ", ISBN='" + getISBN() + '\'' +
                ", dureeEnMinutes=" + dureeEnMinutes +
                ", narrateur='" + narrateur + '\'' +
                '}';
    }
}
