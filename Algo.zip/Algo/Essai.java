
// Essai.java
import java.util.List;

public class Essai extends Livre {
    private String domaine;
    private List<String> motsCles;

    public Essai(String titre, String auteur, int anneePublication, String ISBN, String domaine,
            List<String> motsCles) {
        super(titre, auteur, anneePublication, ISBN);
        this.domaine = domaine;
        this.motsCles = motsCles;

    }

    // Getters et setters pour 'domaine'
    public String getDomaine() {
        return domaine;
    }

    public void setDomaine(String domaine) {
        this.domaine = domaine;
    }

    // Getters et setters pour 'motsCles'
    public List<String> getMotsCles() {
        return motsCles;
    }

    public void setMotsCles(List<String> motsCles) {
        this.motsCles = motsCles;
    }

    @Override
    public String toString() {
        return "Essai{" +
                "titre='" + getTitre() + '\'' +
                ", auteur='" + getAuteur() + '\'' +
                ", anneePublication=" + getAnneePublication() +
                ", ISBN='" + getISBN() + '\'' +
                ", domaine='" + domaine + '\'' +
                ", motsCles=" + motsCles +
                '}';
    }
}
