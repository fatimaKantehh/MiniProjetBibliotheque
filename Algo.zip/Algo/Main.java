import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Pair;
import javafx.beans.property.SimpleStringProperty;

public class Main extends Application {

    private Bibliotheque bibliotheque = new Bibliotheque();
    private Stage primaryStage;

    // Créer une étiquette pour afficher les livres empruntés
    Label livresEmpruntesLabel = new Label();

    // Créer une instance de Utilisateur et lui passer livresEmpruntesLabel
    Utilisateur utilisateur = new Utilisateur(livresEmpruntesLabel);

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        afficherPageAccueil();
    }

    private void afficherPageAccueil() {
        Button adminButton = new Button("Administrateur");
        Button utilisateurButton = new Button("Utilisateur");

        adminButton.setOnAction(e -> MenuAdmin(primaryStage, bibliotheque));
        utilisateurButton.setOnAction(e -> MenuUser(primaryStage, bibliotheque, null));

        VBox accueilBox = new VBox(10, adminButton, utilisateurButton);
        Scene scene = new Scene(accueilBox, 600, 450);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.setTitle("Accueil Bibliothèque");
        primaryStage.show();
    }

    private void MenuAdmin(Stage stage, Bibliotheque bibliotheque) {
        Button retourAccueilButton = new Button("Retour à l'accueil");
        retourAccueilButton.setOnAction(e -> afficherPageAccueil());

        // Ajoutez vos autres éléments pour le menu admin ici
        VBox adminBox = new VBox(10, retourAccueilButton);

        // les boutons pour le menu de l'admin
        Button AjouterLivre = new Button("Ajouter un livre");
        AjouterLivre.setOnAction(event -> {
            // Dialogue pour choisir le type de livre
            ChoiceDialog<String> typeDialog = new ChoiceDialog<>("Roman", "Roman", "Essai", "Livre Audio");
            typeDialog.setTitle("Type de Livre");
            typeDialog.setHeaderText("Sélectionnez le type de livre:");
            Optional<String> typeResult = typeDialog.showAndWait();

            // Si un type de livre a été sélectionné
            typeResult.ifPresent(type -> {
                Dialog<Livre> dialog = new Dialog<>();
                dialog.setTitle("Ajouter un " + type);
                dialog.setHeaderText("Entrez les informations pour le " + type);

                // Configurer les boutons
                ButtonType ajouterButtonType = new ButtonType("Ajouter", ButtonBar.ButtonData.OK_DONE);
                dialog.getDialogPane().getButtonTypes().addAll(ajouterButtonType, ButtonType.CANCEL);

                // Créer les champs de texte pour les entrées utilisateur
                GridPane grid = new GridPane();
                grid.setHgap(10);
                grid.setVgap(10);

                TextField titreField = new TextField();
                TextField auteurField = new TextField();
                TextField anneeField = new TextField();
                TextField isbnField = new TextField();
                TextField genreField = new TextField();
                CheckBox estUneSerieCheck = new CheckBox();
                TextField numeroSerieField = new TextField();
                TextField domaineField = new TextField();
                TextField motsClesField = new TextField();
                TextField dureeField = new TextField();
                TextField narrateurField = new TextField();

                grid.add(new Label("Titre:"), 0, 0);
                grid.add(titreField, 1, 0);
                grid.add(new Label("Auteur:"), 0, 1);
                grid.add(auteurField, 1, 1);
                grid.add(new Label("Année de Publication:"), 0, 2);
                grid.add(anneeField, 1, 2);
                grid.add(new Label("ISBN:"), 0, 3);
                grid.add(isbnField, 1, 3);

                // Ajouter des champs spécifiques pour "Roman"
                if ("Roman".equals(type)) {
                    grid.add(new Label("Genre:"), 0, 4);
                    grid.add(genreField, 1, 4);
                    grid.add(new Label("Est une série:"), 0, 5);
                    grid.add(estUneSerieCheck, 1, 5);
                    grid.add(new Label("Numéro dans la série:"), 0, 6);
                    grid.add(numeroSerieField, 1, 6);
                }
                // Ajouter des champs spécifiques pour "Essai"
                else if ("Essai".equals(type)) {
                    grid.add(new Label("Domaine:"), 0, 4);
                    grid.add(domaineField, 1, 4);
                    grid.add(new Label("Mots-clés (séparés par des virgules):"), 0, 5);
                    grid.add(motsClesField, 1, 5);
                }
                // Ajouter des champs spécifiques pour "Livre Audio"
                else if ("Livre Audio".equals(type)) {
                    grid.add(new Label("Durée (en minutes):"), 0, 4);
                    grid.add(dureeField, 1, 4);
                    grid.add(new Label("Narrateur:"), 0, 5);
                    grid.add(narrateurField, 1, 5);
                }

                dialog.getDialogPane().setContent(grid);

                // Convertir les résultats en un nouveau livre lors de l'appui sur le bouton
                // Ajouter
                dialog.setResultConverter(dialogButton -> {
                    if (dialogButton == ajouterButtonType) {
                        try {
                            String titre = titreField.getText().trim();
                            String auteur = auteurField.getText().trim();
                            int annee = Integer.parseInt(anneeField.getText().trim());
                            String isbn = isbnField.getText().trim();
                            // Créer une instance du type de livre choisi
                            if ("Roman".equals(type)) {
                                String genre = genreField.getText().trim();
                                boolean estUneSerie = estUneSerieCheck.isSelected();
                                int numeroDansLaSerie = Integer.parseInt(numeroSerieField.getText().trim());
                                return new Roman(titre, auteur, annee, isbn, genre, estUneSerie, numeroDansLaSerie);
                            } else if ("Essai".equals(type)) {
                                String domaine = domaineField.getText().trim();
                                List<String> motsCles = Arrays
                                        .asList(motsClesField.getText().trim().split("\\s*,\\s*"));
                                return new Essai(titre, auteur, annee, isbn, domaine, motsCles);
                            } else if ("Livre Audio".equals(type)) {
                                int dureeEnMinutes = Integer.parseInt(dureeField.getText().trim());
                                String narrateur = narrateurField.getText().trim();
                                return new LivreAudio(titre, auteur, annee, isbn, dureeEnMinutes, narrateur);
                            }
                        } catch (NumberFormatException e) {
                            // Gérer l'erreur ici, par exemple en affichant une alerte
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Erreur de saisie");
                            alert.setHeaderText("Problème de saisie des informations");
                            alert.setContentText("Veuillez vérifier les informations saisies et réessayer.");
                            alert.showAndWait();
                            return null;
                        }
                    }
                    return null;
                });

                Optional<Livre> result = dialog.showAndWait();
                result.ifPresent(nouveauLivre -> {
                    // Ajouter le livre à la bibliothèque
                    bibliotheque.ajouterLivre(nouveauLivre);
                    // Mettre à jour l'interface utilisateur
                    // ...
                });
            });
        });

        Button ModifierLivre = new Button("Modifier un livre");
        ModifierLivre.setOnAction(event -> {
            TextInputDialog isbnDialog = new TextInputDialog();
            isbnDialog.setTitle("Modifier un livre");
            isbnDialog.setHeaderText("Entrez l'ISBN du livre à modifier:");
            Optional<String> isbnResult = isbnDialog.showAndWait();

            isbnResult.ifPresent(isbn -> {
                Livre livreAModifier = bibliotheque.rechercherLivre(isbn.trim());
                if (livreAModifier != null) {
                    // Créez un dialogue personnalisé pour la modification du livre
                    Dialog<Livre> dialog = new Dialog<>();
                    dialog.setTitle("Modifier le Livre");
                    dialog.setHeaderText("Modifier les informations du livre");

                    ButtonType modifierButtonType = new ButtonType("Modifier", ButtonBar.ButtonData.OK_DONE);
                    dialog.getDialogPane().getButtonTypes().addAll(modifierButtonType, ButtonType.CANCEL);

                    GridPane grid = new GridPane();
                    grid.setHgap(10);
                    grid.setVgap(10);

                    TextField titreField = new TextField(livreAModifier.getTitre());
                    TextField auteurField = new TextField(livreAModifier.getAuteur());
                    TextField anneeField = new TextField(String.valueOf(livreAModifier.getAnneePublication()));
                    TextField isbnField = new TextField(livreAModifier.getISBN());
                    isbnField.setDisable(true); // L'ISBN ne devrait pas être modifiable

                    grid.add(new Label("Titre:"), 0, 0);
                    grid.add(titreField, 1, 0);
                    grid.add(new Label("Auteur:"), 0, 1);
                    grid.add(auteurField, 1, 1);
                    grid.add(new Label("Année de Publication:"), 0, 2);
                    grid.add(anneeField, 1, 2);
                    grid.add(new Label("ISBN:"), 0, 3);
                    grid.add(isbnField, 1, 3);

                    // Si le livre est d'un type spécifique, ajoutez des champs spécifiques à ce
                    // type
                    // Par exemple, si c'est un Roman, ajoutez des champs pour 'genre',
                    // 'estUneSerie', etc.
                    if (livreAModifier instanceof Roman) {
                        Roman roman = (Roman) livreAModifier;
                        // Ajoutez des champs spécifiques pour les attributs d'un Roman
                        // ...
                    } else if (livreAModifier instanceof Essai) {
                        Essai essai = (Essai) livreAModifier;
                        // Ajoutez des champs spécifiques pour les attributs d'un Essai
                        // ...
                    } else if (livreAModifier instanceof LivreAudio) {
                        LivreAudio livreAudio = (LivreAudio) livreAModifier;
                        // Ajoutez des champs spécifiques pour les attributs d'un Livre Audio
                        // ...
                    }

                    dialog.getDialogPane().setContent(grid);

                    // Convertissez le résultat en modifications lorsque le bouton Modifier est
                    // cliqué
                    dialog.setResultConverter(dialogButton -> {
                        if (dialogButton == modifierButtonType) {
                            try {
                                String titre = titreField.getText().trim();
                                String auteur = auteurField.getText().trim();
                                int annee = Integer.parseInt(anneeField.getText().trim());
                                // Appliquez les modifications au livre trouvé
                                livreAModifier.setTitre(titre);
                                livreAModifier.setAuteur(auteur);
                                livreAModifier.setAnneePublication(annee);
                                // Si des champs supplémentaires pour des types spécifiques de livres ont été
                                // modifiés,
                                // appliquez ces modifications ici
                                return livreAModifier;
                            } catch (NumberFormatException e) {
                                // Gérer l'erreur ici
                                Alert alert = new Alert(Alert.AlertType.ERROR);
                                alert.setTitle("Erreur de saisie");
                                alert.setHeaderText("Problème de saisie des informations");
                                alert.setContentText("Veuillez vérifier les informations saisies et réessayer.");
                                alert.showAndWait();
                                return null;
                            }
                        }
                        return null;
                    });

                    Optional<Livre> result = dialog.showAndWait();
                    result.ifPresent(livre -> {
                        bibliotheque.modifierLivre(isbn, livre);
                        // Mettre à jour l'interface utilisateur avec les informations du livre modifié
                    });
                } else {
                    // Afficher un message disant que le livre avec cet ISBN n'a pas été trouvé
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Livre non trouvé");
                    alert.setHeaderText(null);
                    alert.setContentText("Aucun livre avec l'ISBN " + isbn + " n'a été trouvé.");
                    alert.showAndWait();
                }
            });
        });

        Button SupprimerLivre = new Button("Supprimer un livre");
        SupprimerLivre.setOnAction(event -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Supprimer un livre");
            dialog.setHeaderText("Entrez l'ISBN du livre à supprimer:");

            String result = dialog.showAndWait().orElse(null);
            if (result != null && !result.isEmpty()) {
                bibliotheque.supprimerLivre(result.trim());
                // Affichez une confirmation ou mettez à jour votre interface utilisateur ici
            }
        });

        Button ListerLivres = new Button("Lister tous les livres");
        ListerLivres.setOnAction(event -> {
            // Créer un TableView pour afficher les livres
            TableView<Livre> table = new TableView<>();

            // Définir les colonnes pour les attributs communs
            TableColumn<Livre, String> columnType = new TableColumn<>("Type");
            columnType.setCellValueFactory(cellData -> {
                Livre livre = cellData.getValue();
                if (livre instanceof Roman) {
                    return new SimpleStringProperty("Roman");
                } else if (livre instanceof Essai) {
                    return new SimpleStringProperty("Essai");
                } else if (livre instanceof LivreAudio) {
                    return new SimpleStringProperty("Livre Audio");
                } else {
                    return new SimpleStringProperty("Autre");
                }
            });

            TableColumn<Livre, String> columnTitre = new TableColumn<>("Titre");
            columnTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));

            TableColumn<Livre, String> columnAuteur = new TableColumn<>("Auteur");
            columnAuteur.setCellValueFactory(new PropertyValueFactory<>("auteur"));

            TableColumn<Livre, Integer> columnAnnee = new TableColumn<>("Année Pub.");
            columnAnnee.setCellValueFactory(new PropertyValueFactory<>("anneePublication"));

            TableColumn<Livre, String> columnISBN = new TableColumn<>("ISBN");
            columnISBN.setCellValueFactory(new PropertyValueFactory<>("ISBN"));

            // Ajouter les colonnes au TableView
            table.getColumns().addAll(columnType, columnTitre, columnAuteur, columnAnnee, columnISBN);

            // Récupérer la liste des livres de la bibliothèque et ajouter à la table
            ObservableList<Livre> livres = FXCollections.observableArrayList(bibliotheque.getListeLivres());
            table.setItems(livres);

            // Créer une nouvelle fenêtre (Stage) ou utiliser un existant pour afficher le
            // TableView
            stage.setTitle("Liste des Livres");
            VBox vbox = new VBox(table);
            Scene scene = new Scene(vbox);
            stage.setScene(scene);
            stage.showAndWait();
        });

        Button EnregistrerRetour = new Button("Enregistrer un retour");
        EnregistrerRetour.setOnAction(event -> {
            // Demander d'abord l'ISBN du livre
            TextInputDialog isbnDialog = new TextInputDialog();
            isbnDialog.setTitle("Enregistrer le retour d'un livre");
            isbnDialog.setHeaderText("Entrez l'ISBN du livre retourné:");
            String isbnResult = isbnDialog.showAndWait().orElse(null);

            // Ensuite, demander le numéro d'identification de l'utilisateur
            TextInputDialog idDialog = new TextInputDialog();
            idDialog.setTitle("Enregistrer le retour d'un livre");
            idDialog.setHeaderText("Entrez le numéro d'identification de l'utilisateur:");
            String idResult = idDialog.showAndWait().orElse(null);

            // Vérifier que ni l'ISBN ni l'ID ne sont nuls ou vides
            if (isbnResult != null && !isbnResult.isEmpty() && idResult != null && !idResult.isEmpty()) {
                try {
                    int userId = Integer.parseInt(idResult.trim()); // Convertir l'ID en int
                    bibliotheque.enregistrerRetour(userId, isbnResult.trim());
                    // Affichez une confirmation ou mettez à jour votre interface utilisateur ici
                } catch (NumberFormatException e) {
                    // Gérer l'erreur si l'ID n'est pas un nombre
                }
            }
        });

        Button VerifierEligibilite = new Button("Vérifier l'éligibilité d'emprunt");
        VerifierEligibilite.setOnAction(event -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Vérifier l'éligibilité d'emprunt");
            dialog.setHeaderText("Entrez le numéro d'identification de l'utilisateur:");

            String result = dialog.showAndWait().orElse(null);
            if (result != null && !result.isEmpty()) {
                int id = Integer.parseInt(result.trim()); // Assurez-vous de gérer NumberFormatException
                boolean isEligible = bibliotheque.verifierEligibilite(id);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Vérification de l'Éligibilité");
                alert.setHeaderText("Éligibilité de l'emprunt pour l'utilisateur ID: " + id);
                alert.setContentText(isEligible ? "L'utilisateur est éligible pour emprunter des livres."
                        : "L'utilisateur n'est pas éligible pour emprunter des livres.");
                alert.showAndWait();
            }
        });

        Button VoirStatistiques = new Button("Afficher les statistiques");
        VoirStatistiques.setOnAction(event -> {
            bibliotheque.calculerStatistiques();
        });

        adminBox.getChildren().addAll(
                AjouterLivre, ModifierLivre, SupprimerLivre, ListerLivres,
                EnregistrerRetour, VerifierEligibilite, VoirStatistiques);

        Scene scene = new Scene(adminBox, 600, 450);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        stage.setScene(scene);
        stage.setTitle("Menu Administrateur");

    }

    private void MenuUser(Stage stage, Bibliotheque bibliotheque, Utilisateur utilisateur) {
        Button retourAccueilButton = new Button("Retour à l'accueil");
        retourAccueilButton.setOnAction(e -> afficherPageAccueil());

        // Ajoutez vos autres éléments pour le menu utilisateur ici
        VBox userBox = new VBox(10, retourAccueilButton);
        // Boutons pour les fonctionnalités du user
        Button RechercherLivre = new Button("Rechercher un livre");
        RechercherLivre.setOnAction(event -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Recherche de livre");
            dialog.setHeaderText("Recherche de livre");
            dialog.setContentText("Entrez le titre, l'auteur ou l'ISBN:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                String recherche = result.get();
                Livre livre = bibliotheque.rechercherLivre(recherche);
                if (livre != null) {
                    // Afficher les informations du livre trouvé
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Livre Trouvé");
                    alert.setHeaderText("Résultats de la recherche:");
                    alert.setContentText(livre.toString());
                    alert.showAndWait();
                } else {
                    // Afficher un message indiquant que le livre n'a pas été trouvé
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Livre Non Trouvé");
                    alert.setHeaderText("Aucun livre correspondant trouvé");
                    alert.setContentText("Aucun résultat pour la recherche: " + recherche);
                    alert.showAndWait();
                }
            }
        });

        Button borrowBookButton = new Button("Emprunter un livre");
        Label messageLabel = new Label();
        borrowBookButton.setOnAction(event -> {
            // Créer un dialogue personnalisé pour saisir les informations
            Dialog<Pair<String, String>> dialog = new Dialog<>();
            dialog.setTitle("Emprunter un livre");
            dialog.setHeaderText("Veuillez entrer les informations suivantes:");

            // Configurer les boutons
            ButtonType emprunterButtonType = new ButtonType("Emprunter", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().addAll(emprunterButtonType, ButtonType.CANCEL);

            // Créer les champs de saisie
            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);

            TextField nameField = new TextField();
            TextField isbnField = new TextField();

            grid.add(new Label("Nom:"), 0, 0);
            grid.add(nameField, 1, 0);
            grid.add(new Label("ISBN du livre:"), 0, 1);
            grid.add(isbnField, 1, 1);

            dialog.getDialogPane().setContent(grid);

            // Convertir le résultat en une paire contenant les informations
            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == emprunterButtonType) {
                    return new Pair<>(nameField.getText(), isbnField.getText());
                }
                return null;
            });

            Optional<Pair<String, String>> result = dialog.showAndWait();

            result.ifPresent(nameIsbn -> {
                String name = nameIsbn.getKey().trim();
                String isbn = nameIsbn.getValue().trim();

                // Remplacer cette ligne par votre logique pour récupérer le livre à partir du
                // code ISBN
                Livre livre = bibliotheque.rechercherLivre(isbn);

                if (livre != null) {
                    EmpruntResult empruntReussi = utilisateur.emprunterLivre(livre);

                    if (empruntReussi != null) {
                        // Afficher un message de confirmation
                        messageLabel.setText("Le livre a été emprunté avec succès.");
                        messageLabel.setStyle("-fx-text-fill: green;"); // Couleur du texte vert pour la confirmation
                    } else {
                        // Afficher un message d'erreur
                        messageLabel.setText(
                                "Le livre n'est pas disponible pour l'emprunt ou l'utilisateur n'est pas éligible.");
                        messageLabel.setStyle("-fx-text-fill: red;"); // Couleur du texte rouge pour l'erreur
                    }
                } else {
                    // Afficher un message d'erreur si le livre n'est pas trouvé
                    messageLabel.setText("Livre non trouvé.");
                    messageLabel.setStyle("-fx-text-fill: red;"); // Couleur du texte rouge pour l'erreur
                }

            });
        });

        Button retournerLivre = new Button("Retourner un livre");
        retournerLivre.setOnAction(event -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Retourner un livre");
            dialog.setHeaderText("Retourner un livre");
            dialog.setContentText("Entrez votre nom et votre numéro d'identification (séparés par une virgule):");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                String input = result.get();
                String[] parts = input.split(",");
                if (parts.length == 2) {
                    String nomUtilisateur = parts[0].trim();
                    int numeroIdentification = Integer.parseInt(parts[1].trim());

                    Utilisateur utilisateurs = bibliotheque.rechercherUtilisateur(nomUtilisateur, numeroIdentification);
                    if (utilisateur != null) {
                        TextInputDialog isbnDialog = new TextInputDialog();
                        isbnDialog.setTitle("Retourner un livre");
                        isbnDialog.setHeaderText("Retourner un livre");
                        isbnDialog.setContentText("Entrez l'ISBN du livre à retourner:");

                        Optional<String> isbnResult = isbnDialog.showAndWait();
                        if (isbnResult.isPresent()) {
                            String isbn = isbnResult.get();
                            bibliotheque.enregistrerRetour(numeroIdentification, isbn);
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Livre Retourné");
                            alert.setHeaderText(null);
                            alert.setContentText("Le livre avec l'ISBN " + isbn + " a été retourné avec succès.");
                            alert.showAndWait();
                        }
                    } else {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Utilisateur Non Trouvé");
                        alert.setHeaderText(null);
                        alert.setContentText(
                                "Utilisateur introuvable. Veuillez vérifier votre nom et votre numéro d'identification.");
                        alert.showAndWait();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Entrée Incorrecte");
                    alert.setHeaderText(null);
                    alert.setContentText(
                            "Veuillez entrer votre nom et votre numéro d'identification (séparés par une virgule).");
                    alert.showAndWait();
                }
            }
        });

        Button VoirEmprunt = new Button("Voir mes emprunts");
        VoirEmprunt.setOnAction(event -> {
            // Appeler la méthode pour afficher les livres empruntés
            String livresEmpruntesText = utilisateur.afficherLivresEmpruntes();

            // Afficher les livres empruntés dans une boîte de dialogue ou tout autre
            // composant de votre interface utilisateur
            // Par exemple, affichez-les dans une fenêtre d'alerte :
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Livres Empruntés");
            alert.setHeaderText(null);
            alert.setContentText(livresEmpruntesText);
            alert.showAndWait();
        });

        // Ajout des boutons à la boîte verticale
        userBox.getChildren().addAll(
                RechercherLivre, borrowBookButton, retournerLivre, VoirEmprunt);

        // Afficher le menu utilisateur
        Scene scene = new Scene(userBox, 600, 450);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        stage.setScene(scene);
        stage.setTitle("Menu Utilisateur");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
